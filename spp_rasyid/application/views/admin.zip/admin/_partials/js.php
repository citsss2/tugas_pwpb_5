
    <!-- Jquery JS-->
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/jquery-3.2.1.min.js')?>"></script>
    <!-- Bootstrap JS-->
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/bootstrap-4.1/popper.min.js')?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/bootstrap-4.1/bootstrap.min.js')?>"></script>
    <!-- Vendor JS -->
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/slick/slick.min.js')?>">
    </script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/wow/wow.min.js')?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/animsition/animsition.min.js')?>"></script>

    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/bootstrap-progressbar/bootstrap-
    progressbar.min.js')?>">

    </script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/counter-up/jquery.waypoints.min.js')?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/counter-up/jquery.counterup.min.js')?>">
    </script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/circle-progress/circle-progress.min.js')?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/perfect-scrollbar/perfect-scrollbar.js')?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/chartjs/Chart.bundle.min.js')?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/vendor/select2/select2.min.js')?>">
    </script>
    <!-- Main JS-->
    <script src="<?php echo base_url('assets/CoolAdmin-master/js/main.js')?>"></script>
    
    <!-- Bootstrap core JavaScript-->
    <script src="<?php echo base_url('assets/CoolAdmin-master/jquery/jquery.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/bootstrap/js/bootstrap.bundle.min.js') ?>"></script>

   <!-- Core plugin JavaScript-->
    <script src="<?php echo base_url('assets/CoolAdmin-master/jquery-easing/jquery.easing.min.js') ?>">
    </script>
    <!-- Page level plugin JavaScript-->
    <script src="<?php echo base_url('assets/CoolAdmin-master/chart.js/Chart.min.js') ?>"></script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/datatables/jquery.dataTables.js') ?>">
    </script>
    <script src="<?php echo base_url('assets/CoolAdmin-master/datatables/dataTables.bootstrap4.js') ?>">
    </script>
    <!-- Custom scripts for all pages-->
    <script src="<?php echo base_url('js/sb-admin.min.js') ?>"></script>
    <!-- Demo scripts for this page-->
    <script src="<?php echo base_url('js/demo/datatables-demo.js') ?>"></script>
    <script src="<?php echo base_url('js/demo/chart-area-demo.js') ?>"></script>
</body>

</html>
<!-- end document-->