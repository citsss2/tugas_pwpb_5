<pre><?php print_r($dataku);?></pre>
